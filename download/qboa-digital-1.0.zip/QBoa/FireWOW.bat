chcp 65001
@echo off
:: Check for administrative privileges
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Solicitando privilégios de patrão...
    goto UACPrompt
) else (
    goto runScript
)

:UACPrompt
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "cmd.exe", "/c ""%~s0""", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    del "%temp%\getadmin.vbs"
    exit /B

:runScript

setlocal enabledelayedexpansion

:: Target directory (defaults to the folder where the script is run)
set "target_dir=%~dp0"
                                             
echo.
echo ===================================================
echo  Pasta Alvo: %target_dir%
echo ===================================================
echo.
echo Pressione qualquer tecla para bloquear todos os executáveis nesta pasta...
pause >nul

:: Loop through all .exe files in the current folder and subfolders
for /R "%target_dir%" %%F in (*.exe) do (
    echo Castigando: %%~nxF
    
    :: Add Outbound Block Rule
    netsh advfirewall firewall add rule name="Blocked_Out_%%~nxF" dir=out program="%%F" action=block profile=any enable=yes >nul
    
    :: Add Inbound Block Rule
    netsh advfirewall firewall add rule name="Blocked_In_%%~nxF" dir=in program="%%F" action=block profile=any enable=yes >nul
)

echo.
echo ===================================================
echo  Pronto! Todo mundo de castigo, ninguém vai ligar pra casa.
echo ===================================================
pause