set "params=%*"
cd /d "%~dp0" && ( if exist "%temp%\getadmin.vbs" del "%temp%\getadmin.vbs" ) && fsutil dirty query %systemdrive% 1>nul 2>nul || (  echo Set UAC = CreateObject^("Shell.Application"^) : UAC.ShellExecute "cmd.exe", "/k cd ""%~sdp0"" && ""%~s0"" %params%", "", "runas", 1 >> "%temp%\getadmin.vbs" && "%temp%\getadmin.vbs" && exit /B )
chcp 65001
mode 76,32
@echo off

cls
echo.
echo                    bbbbbbbb                                               
echo       QQQQQQQQQ    b::::::b                                               
echo     QQ:::::::::QQ  b::::::b                                               
echo   QQ:::::::::::::QQb::::::b                                               
echo  Q:::::::QQQ:::::::Qb:::::b                                               
echo  Q::::::O   Q::::::Qb:::::bbbbbbbbb       ooooooooooo     aaaaaaaaaaaaa   
echo  Q:::::O     Q:::::Qb::::::::::::::bb   oo:::::::::::oo   a::::::::::::a  
echo  Q:::::O     Q:::::Qb::::::::::::::::b o:::::::::::::::o  aaaaaaaaa:::::a 
echo  Q:::::O     Q:::::Qb:::::bbbbb:::::::bo:::::ooooo:::::o           a::::a 
echo  Q:::::O     Q:::::Qb:::::b    b::::::bo::::o     o::::o    aaaaaaa:::::a 
echo  Q:::::O     Q:::::Qb:::::b     b:::::bo::::o     o::::o  aa::::::::::::a 
echo  Q:::::O  QQQQ:::::Qb:::::b     b:::::bo::::o     o::::o a::::aaaa::::::a 
echo  Q::::::O Q::::::::Qb:::::b     b:::::bo::::o     o::::oa::::a    a:::::a 
echo  Q:::::::QQ::::::::Qb:::::bbbbbb::::::bo:::::ooooo:::::oa::::a    a:::::a 
echo   QQ::::::::::::::Q b::::::::::::::::b o:::::::::::::::oa:::::aaaa::::::a 
echo     QQ:::::::::::Q  b:::::::::::::::b   oo:::::::::::oo  a::::::::::aa:::a
echo       QQQQQQQQ::::QQbbbbbbbbbbbbbbbb      ooooooooooo     aaaaaaaaaa  aaaa
echo               Q:::::Q                                                     
echo                QQQQQQ                                                     
echo.                                                                      
echo  D           I           G           I           T           A           L
echo.
echo  Escolha uma opção:
echo.
echo  1. Limpeza Leve
echo  2. Limpeza Leve (Desligar ao concluir)
echo  3. Limpeza Intermediária
echo  4. Limpeza Intermediária (Desligar ao concluir)
echo  5. Limpeza Pesada
echo  6. Limpeza Pesada (Desligar ao concluir)
echo.
set /p choice="  Insira um número (1-6): "

if "%choice%"=="1" goto cmd1
if "%choice%"=="2" goto cmd1s
if "%choice%"=="3" goto cmd2
if "%choice%"=="4" goto cmd2s
if "%choice%"=="5" goto cmd3
if "%choice%"=="6" goto cmd3s

echo Escolha inexistente.
pause
exit

:cmd1
echo Limpando só onde o papa passa...
echo Pagando o dízimo...
DISM /online /cleanup-image /RestoreHealth
echo Verificando todo o sistema operacional por arquivos alterados...
sfc /scannow
echo Limpeza concluída com súúúúúúúúúcéééééésssssooooowwww!
pause
exit

:cmd1s
echo Limpando só onde o papa passa...
echo Pagando o dízimo...
DISM /online /cleanup-image /RestoreHealth
echo Verificando todo o sistema operacional por arquivos alterados...
sfc /scannow
echo Limpeza concluída com súúúúúúúúúcéééééésssssooooowwww!
shutdown -s
exit

:cmd2
echo Limpando decentemente...
echo Pagando o dízimo...
DISM /online /cleanup-image /RestoreHealth
echo Verificando todo o sistema operacional por arquivos alterados...
sfc /scannow
echo Apagando histórico de vídeos de travecos...
cd bin
bleachbit_console.exe --clean deepscan.ds_store deepscan.tmp firefox.cache firefox.crash_reports firefox.session firefox.site_data firefox.vacuum flash.cache flash.cookies google_chrome.cache google_chrome.session google_chrome.crash_reports google_chrome.vacuum google_chrome.site_data internet_explorer.cache internet_explorer.logs libreoffice.historymicrosoft_edge.cache microsoft_edge.crash_reports microsoft_edge.session microsoft_edge.site_data microsoft_edge.vacuum microsoft_office.debug_logs microsoft_office.mru system.clipboard system.recycle_bin system.tmp thunderbird.cache thunderbird.sessionjson thunderbird.vacuum vlc.memory_dump vlc.mru windows_defender.temp winrar.history winrar.temp
cd ..
echo Limpeza concluída com súúúúúúúúúcéééééésssssooooowwww!
pause
exit

:cmd2s
echo Limpando decentemente...
echo Pagando o dízimo...
DISM /online /cleanup-image /RestoreHealth
echo Verificando todo o sistema operacional por arquivos alterados...
sfc /scannow
echo Apagando histórico de vídeos de travecos...
cd bin
bleachbit_console.exe --clean deepscan.ds_store deepscan.tmp firefox.cache firefox.crash_reports firefox.session firefox.site_data firefox.vacuum flash.cache flash.cookies google_chrome.cache google_chrome.session google_chrome.crash_reports google_chrome.vacuum google_chrome.site_data internet_explorer.cache internet_explorer.logs libreoffice.historymicrosoft_edge.cache microsoft_edge.crash_reports microsoft_edge.session microsoft_edge.site_data microsoft_edge.vacuum microsoft_office.debug_logs microsoft_office.mru system.clipboard system.recycle_bin system.tmp thunderbird.cache thunderbird.sessionjson thunderbird.vacuum vlc.memory_dump vlc.mru windows_defender.temp winrar.history winrar.temp
cd ..
echo Limpeza concluída com súúúúúúúúúcéééééésssssooooowwww!
shutdown -s
exit

:cmd3
echo Limpando com vicissitude!
echo Pagando o dízimo...
DISM /online /cleanup-image /RestoreHealth
echo Verificando todo o sistema operacional por arquivos alterados...
sfc /scannow
echo Apagando histórico de vídeos de travecos...
cd bin
bleachbit_console.exe --clean deepscan.ds_store deepscan.tmp firefox.cache firefox.crash_reports firefox.session firefox.site_data firefox.vacuum flash.cache flash.cookies google_chrome.cache google_chrome.session google_chrome.crash_reports google_chrome.vacuum google_chrome.site_data internet_explorer.cache internet_explorer.logs libreoffice.historymicrosoft_edge.cache microsoft_edge.crash_reports microsoft_edge.session microsoft_edge.site_data microsoft_edge.vacuum microsoft_office.debug_logs microsoft_office.mru system.clipboard system.recycle_bin system.tmp thunderbird.cache thunderbird.sessionjson thunderbird.vacuum vlc.memory_dump vlc.mru windows_defender.temp winrar.history winrar.temp
echo Apagando bagulhada do tela azul.
cd ..
cleanmgr /sagerun:1
echo Limpeza concluída com súúúúúúúúúcéééééésssssooooowwww!
pause
exit

:cmd3s
echo Limpando com vicissitude!
echo Pagando o dízimo...
DISM /online /cleanup-image /RestoreHealth
echo Verificando todo o sistema operacional por arquivos alterados...
sfc /scannow
echo Apagando histórico de vídeos de travecos...
cd bin
bleachbit_console.exe --clean deepscan.ds_store deepscan.tmp firefox.cache firefox.crash_reports firefox.session firefox.site_data firefox.vacuum flash.cache flash.cookies google_chrome.cache google_chrome.session google_chrome.crash_reports google_chrome.vacuum google_chrome.site_data internet_explorer.cache internet_explorer.logs libreoffice.historymicrosoft_edge.cache microsoft_edge.crash_reports microsoft_edge.session microsoft_edge.site_data microsoft_edge.vacuum microsoft_office.debug_logs microsoft_office.mru system.clipboard system.recycle_bin system.tmp thunderbird.cache thunderbird.sessionjson thunderbird.vacuum vlc.memory_dump vlc.mru windows_defender.temp winrar.history winrar.temp
cd ..
echo Apagando bagulhada do tela azul.
cleanmgr /sagerun:1
echo Limpeza concluída com súúúúúúúúúcéééééésssssooooowwww!
shutdown -s
exit